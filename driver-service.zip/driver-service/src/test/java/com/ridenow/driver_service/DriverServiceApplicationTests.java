package com.ridenow.driver_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DriverServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
